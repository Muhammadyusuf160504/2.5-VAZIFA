

document.querySelector(".header__logo").addEventListener("click", function() {
    document.body.classList.toggle("dark-mode")
})